<?php
include 'koneksi.php';
$id      = mysqli_real_escape_string($koneksi, $_POST['id_customer']);
$nama    = mysqli_real_escape_string($koneksi, $_POST['nama_customer']);
$jk      = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
$alamat  = mysqli_real_escape_string($koneksi, $_POST['alamat_customer']);
$telp    = mysqli_real_escape_string($koneksi, $_POST['telepon_customer']);
$email   = mysqli_real_escape_string($koneksi, $_POST['email_customer']);
$pass    = mysqli_real_escape_string($koneksi, $_POST['pass_customer']);
mysqli_query($koneksi,"INSERT INTO tb_customer VALUES ('$id','$nama','$jk','$alamat','$telp','$email','$pass')");
header("location:data_customer.php?pesan=input");
exit();
?>
