<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Transaksi Pembelian</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Laporan Transaksi Pembelian</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print">
        <form method="get" style="display:inline-flex;gap:10px;align-items:center">
            <label>Filter Bulan:</label>
            <input type="month" name="bulan" value="<?= isset($_GET['bulan'])?$_GET['bulan']:date('Y-m') ?>">
            <input type="submit" value=" Filter" class="btn-primary" style="padding:6px 14px">
            <a href="laporan_pembelian.php" class="tombol btn-secondary" style="padding:6px 14px">Reset</a>
        </form>
        &nbsp;&nbsp;
        <button onclick="window.print()" class="btn-info"> Cetak</button>
    </div>
    <div class="card">
        <?php
        $where = '';
        if(isset($_GET['bulan']) && $_GET['bulan']){
            $bln = mysqli_real_escape_string($koneksi, $_GET['bulan']);
            $where = "WHERE p.tanggal_pembelian LIKE '$bln%'";
            echo "<h3> Laporan Pembelian: ".date('F Y', strtotime($bln.'-01'))."</h3>";
        } else {
            echo "<h3> Laporan Seluruh Transaksi Pembelian</h3>";
        }
        $q = mysqli_query($koneksi,"SELECT p.*, s.nama_supplier FROM tb_pembelian p LEFT JOIN tb_supplier s ON p.id_supplier=s.id_supplier $where ORDER BY p.tanggal_pembelian DESC");
        $total_hrg=0; $total_brg=0;
        $rows = [];
        while($d = mysqli_fetch_array($q)) { $rows[]=$d; $total_hrg+=$d['total_hargaall']; $total_brg+=$d['total_barangall']; }
        ?>
        <table class="table">
            <tr><th>No</th><th>No. Pembelian</th><th>Tanggal</th><th>Supplier</th><th>Total Barang</th><th>Total Harga</th></tr>
            <?php $no=1; foreach($rows as $d): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['no_pembelian'] ?></td>
                <td><?= $d['tanggal_pembelian'] ?></td>
                <td style="text-align:left"><?= $d['nama_supplier'] ?></td>
                <td><?= $d['total_barangall'] ?></td>
                <td>Rp <?= number_format($d['total_hargaall'],0,',','.') ?></td>
            </tr>
            <?php endforeach; ?>
            <tr style="background:#3d8b8b;color:#fff;font-weight:bold">
                <td colspan="4" style="text-align:right;padding-right:12px">TOTAL</td>
                <td><?= $total_brg ?></td>
                <td>Rp <?= number_format($total_hrg,0,',','.') ?></td>
            </tr>
        </table>
    </div>
</div>
</body>
</html>
