<?php include "koneksi.php"; ?>
<?php 
session_start();
if($_SESSION['status'] != "login"){
    header("location:login.php?pesan=belum_login");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Gudang - Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1> Aplikasi Gudang</h1>
    <h2>Management System for Warehouse</h2>
</div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php
    $jml_barang   = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_barang"));
    $jml_customer = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_customer"));
    $jml_supplier = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_supplier"));
    $jml_beli     = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_pembelian"));
    $jml_jual     = mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_penjualan"));
    $total_stok   = mysqli_fetch_array(mysqli_query($koneksi,"SELECT SUM(stok) as ts FROM tb_barang"));
    ?>
    <div class="card">
        <h3> Ringkasan Data</h3>
        <table class="table">
            <tr><th>Total Barang</th><th>Total Customer</th><th>Total Supplier</th><th>Total Pembelian</th><th>Total Penjualan</th><th>Total Stok</th></tr>
            <tr>
                <td><?= $jml_barang ?></td>
                <td><?= $jml_customer ?></td>
                <td><?= $jml_supplier ?></td>
                <td><?= $jml_beli ?></td>
                <td><?= $jml_jual ?></td>
                <td><?= $total_stok['ts'] ?></td>
            </tr>
        </table>
    </div>

    <div class="card">
        <h3> Stok Barang Hampir Habis (≤ 5)</h3>
        <?php
        $q_stok = mysqli_query($koneksi,"SELECT b.*, j.jenis FROM tb_barang b LEFT JOIN tb_jenis j ON b.kode_jenis=j.kode_jenis WHERE b.stok <= 5 ORDER BY b.stok ASC");
        if(mysqli_num_rows($q_stok) > 0):
        ?>
        <table class="table">
            <tr><th>Kode</th><th>Nama Barang</th><th>Jenis</th><th>Stok</th><th>Harga Jual</th></tr>
            <?php while($r = mysqli_fetch_array($q_stok)): ?>
            <tr>
                <td><?= $r['kd_barang'] ?></td>
                <td><?= $r['nama_barang'] ?></td>
                <td><?= $r['jenis'] ?></td>
                <td style="color:red;font-weight:bold"><?= $r['stok'] ?></td>
                <td>Rp <?= number_format($r['harga_jual'],0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <?php else: echo '<p style="color:green"> Semua stok barang aman.</p>'; endif; ?>
    </div>

    <div class="card">
        <h3> Transaksi Pembelian Terbaru</h3>
        <?php
        $q_beli = mysqli_query($koneksi,"SELECT p.*, s.nama_supplier FROM tb_pembelian p LEFT JOIN tb_supplier s ON p.id_supplier=s.id_supplier ORDER BY p.no_pembelian DESC LIMIT 5");
        ?>
        <table class="table">
            <tr><th>No. Pembelian</th><th>Tanggal</th><th>Supplier</th><th>Total Barang</th><th>Total Harga</th></tr>
            <?php while($r = mysqli_fetch_array($q_beli)): ?>
            <tr>
                <td><?= $r['no_pembelian'] ?></td>
                <td><?= $r['tanggal_pembelian'] ?></td>
                <td><?= $r['nama_supplier'] ?></td>
                <td><?= $r['total_barangall'] ?></td>
                <td>Rp <?= number_format($r['total_hargaall'],0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
