<?php
include 'koneksi.php';
$id = mysqli_real_escape_string($koneksi, $_GET['id']);
mysqli_query($koneksi,"DELETE FROM tb_customer WHERE id_customer='$id'");
header("location:data_customer.php?pesan=hapus");
exit();
?>
