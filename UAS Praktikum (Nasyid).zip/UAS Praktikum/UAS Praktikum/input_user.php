<!DOCTYPE html>
<html>
<head>
    <title>Tambah Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Tambah Data Admin</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3> Form Tambah Admin</h3>
        <a href="data_user.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="input_aksi_admin.php" method="post">
            <table class="table-form">
                <tr><td>Username</td><td>:</td><td><input type="text" name="username" placeholder="Masukkan username" required></td></tr>
                <tr><td>Password</td><td>:</td><td><input type="password" name="password" placeholder="Masukkan password" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value=" Simpan Data"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
