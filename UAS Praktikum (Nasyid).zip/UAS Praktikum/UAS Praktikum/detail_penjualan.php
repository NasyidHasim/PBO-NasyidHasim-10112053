<?php
include "koneksi.php";
$no = mysqli_real_escape_string($koneksi, $_GET['no']);
$header = mysqli_fetch_array(mysqli_query($koneksi,"SELECT p.*, c.nama_customer, c.telepon_customer, c.alamat_customer FROM tb_penjualan p LEFT JOIN tb_customer c ON p.id_customer=c.id_customer WHERE p.no_penjualan='$no'"));
if(!$header) { header("location:transaksi_penjualan.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Penjualan <?= $no ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Detail Transaksi Penjualan</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print">
        <a href="transaksi_penjualan.php" class="tombol btn-secondary"> Kembali</a>
        &nbsp;<button onclick="window.print()" class="btn-info"> Cetak</button>
    </div>
    <div class="card">
        <h3> Detail Penjualan: <?= $header['no_penjualan'] ?></h3>
        <table class="table-form">
            <tr><td width="160">No. Penjualan</td><td>:</td><td><b><?= $header['no_penjualan'] ?></b></td></tr>
            <tr><td>Tanggal</td><td>:</td><td><?= $header['tanggal_penjualan'] ?></td></tr>
            <tr><td>Customer</td><td>:</td><td><?= $header['nama_customer'] ?></td></tr>
            <tr><td>Telepon</td><td>:</td><td><?= $header['telepon_customer'] ?></td></tr>
            <tr><td>Alamat</td><td>:</td><td><?= $header['alamat_customer'] ?></td></tr>
        </table>
        <br>
        <h4> Barang yang Dijual</h4>
        <table class="table">
            <tr><th>No</th><th>Kode Barang</th><th>Nama Barang</th><th>Jenis</th><th>Jumlah</th><th>Harga Satuan</th><th>Subtotal</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT d.*, b.nama_barang, j.jenis FROM detail_penjualan d LEFT JOIN tb_barang b ON d.kd_barang=b.kd_barang LEFT JOIN tb_jenis j ON d.kode_jenis=j.kode_jenis WHERE d.no_penjualan='$no'");
            $no_i=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no_i++ ?></td>
                <td><?= $d['kd_barang'] ?></td>
                <td style="text-align:left"><?= $d['nama_barang'] ?></td>
                <td><?= $d['jenis'] ?></td>
                <td><?= $d['jumlah_barang'] ?></td>
                <td>Rp <?= number_format($d['harga_barang'],0,',','.') ?></td>
                <td>Rp <?= number_format($d['total_harga'],0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
            <tr style="background:#e8f5f5;font-weight:bold">
                <td colspan="4">TOTAL</td>
                <td><?= $header['total_barangall'] ?></td>
                <td>-</td>
                <td>Rp <?= number_format($header['total_hargaall'],0,',','.') ?></td>
            </tr>
        </table>
    </div>
</div>
</body>
</html>
