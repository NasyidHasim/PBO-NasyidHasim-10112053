<?php
include 'koneksi.php';
$id    = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
$nama  = mysqli_real_escape_string($koneksi, $_POST['nama_supplier']);
$adr   = mysqli_real_escape_string($koneksi, $_POST['alamat_supplier']);
$telp  = mysqli_real_escape_string($koneksi, $_POST['telepon_supplier']);
$email = mysqli_real_escape_string($koneksi, $_POST['email_supplier']);
$pass  = mysqli_real_escape_string($koneksi, $_POST['pass_supplier']);
mysqli_query($koneksi,"INSERT INTO tb_supplier VALUES ('$id','$nama','$adr','$telp','$email','$pass')");
header("location:data_supplier.php?pesan=input");
exit();
?>
