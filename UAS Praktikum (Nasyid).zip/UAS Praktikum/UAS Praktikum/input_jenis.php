<!DOCTYPE html>
<html>
<head><title>Tambah Jenis</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Tambah Jenis Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>➕ Form Tambah Jenis</h3>
        <a href="data_jenis.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="input_aksi_jenis.php" method="post">
            <table class="table-form">
                <tr><td>Kode Jenis</td><td>:</td><td><input type="text" name="kode_jenis" placeholder="Cth: JNS005" required></td></tr>
                <tr><td>Nama Jenis</td><td>:</td><td><input type="text" name="jenis" placeholder="Cth: Elektronik" required></td></tr>
                <tr><td>Satuan</td><td>:</td><td><input type="text" name="satuan" placeholder="Cth: Unit, Kg, Liter" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Jenis"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
