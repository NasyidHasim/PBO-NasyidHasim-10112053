<?php
// File hapus generik - redirect ke data_user
include 'koneksi.php';
if(isset($_GET['id'])){
    $id = (int) $_GET['id'];
    mysqli_query($koneksi,"DELETE FROM user WHERE id_user='$id'");
}
header("location:data_user.php?pesan=hapus");
exit();
?>
