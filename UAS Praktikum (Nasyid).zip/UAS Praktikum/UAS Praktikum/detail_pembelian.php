<?php
include "koneksi.php";
$no = mysqli_real_escape_string($koneksi, $_GET['no']);
$header = mysqli_fetch_array(mysqli_query($koneksi,"SELECT p.*, s.nama_supplier, s.alamat_supplier, s.telepon_supplier FROM tb_pembelian p LEFT JOIN tb_supplier s ON p.id_supplier=s.id_supplier WHERE p.no_pembelian='$no'"));
if(!$header) { header("location:transaksi_pembelian.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Pembelian <?= $no ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Detail Transaksi Pembelian</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print" style="margin-bottom:10px">
        <a href="transaksi_pembelian.php" class="tombol btn-secondary">< Kembali</a>
        &nbsp;<button onclick="window.print()" class="btn-info"> Cetak</button>
    </div>
    <div class="card">
        <h3> Detail Pembelian: <?= $header['no_pembelian'] ?></h3>
        <table class="table-form">
            <tr><td width="160">No. Pembelian</td><td>:</td><td><b><?= $header['no_pembelian'] ?></b></td></tr>
            <tr><td>Tanggal</td><td>:</td><td><?= $header['tanggal_pembelian'] ?></td></tr>
            <tr><td>Supplier</td><td>:</td><td><?= $header['nama_supplier'] ?></td></tr>
            <tr><td>Alamat Supplier</td><td>:</td><td><?= $header['alamat_supplier'] ?></td></tr>
            <tr><td>Telepon</td><td>:</td><td><?= $header['telepon_supplier'] ?></td></tr>
        </table>
        <br>
        <h4> Barang yang Dibeli</h4>
        <table class="table">
            <tr><th>No</th><th>Kode Barang</th><th>Nama Barang</th><th>Jenis</th><th>Jumlah</th><th>Harga Satuan</th><th>Subtotal</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT d.*, b.nama_barang, j.jenis FROM detail_pembelian d LEFT JOIN tb_barang b ON d.kd_barang=b.kd_barang LEFT JOIN tb_jenis j ON d.kode_jenis=j.kode_jenis WHERE d.no_pembelian='$no'");
            $no_i=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no_i++ ?></td>
                <td><?= $d['kd_barang'] ?></td>
                <td style="text-align:left"><?= $d['nama_barang'] ?></td>
                <td><?= $d['jenis'] ?></td>
                <td><?= $d['jumlah_barang'] ?></td>
                <td>Rp <?= number_format($d['harga_barang'],0,',','.') ?></td>
                <td>Rp <?= number_format($d['total_harga'],0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
            <tr style="background:#e8f5f5;font-weight:bold">
                <td colspan="4">TOTAL</td>
                <td><?= $header['total_barangall'] ?></td>
                <td>-</td>
                <td>Rp <?= number_format($header['total_hargaall'],0,',','.') ?></td>
            </tr>
        </table>
    </div>
</div>
</body>
</html>
