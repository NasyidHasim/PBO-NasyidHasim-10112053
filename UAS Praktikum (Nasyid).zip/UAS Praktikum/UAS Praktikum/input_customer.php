<!DOCTYPE html>
<html>
<head>
    <title>Tambah Customer</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Tambah Data Customer</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>➕ Form Tambah Customer</h3>
        <a href="data_customer.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="input_aksi_customer.php" method="post">
            <table class="table-form">
                <tr><td>ID Customer</td><td>:</td><td><input type="text" name="id_customer" placeholder="Cth: CS003" required></td></tr>
                <tr><td>Nama Customer</td><td>:</td><td><input type="text" name="nama_customer" placeholder="Masukkan nama" required></td></tr>
                <tr>
                    <td>Jenis Kelamin</td><td>:</td>
                    <td>
                        <select name="jenis_kelamin" required>
                            <option value="">-- Pilih --</option>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </td>
                </tr>
                <tr><td>Alamat</td><td>:</td><td><textarea name="alamat_customer" rows="3" placeholder="Masukkan alamat" required></textarea></td></tr>
                <tr><td>No. Telepon</td><td>:</td><td><input type="text" name="telepon_customer" placeholder="08xxxxxxxxxx" required></td></tr>
                <tr><td>Email</td><td>:</td><td><input type="email" name="email_customer" placeholder="email@example.com"></td></tr>
                <tr><td>Password</td><td>:</td><td><input type="password" name="pass_customer" placeholder="Masukkan password" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Customer"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
