<?php
include 'koneksi.php';
$kd     = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
$jenis  = mysqli_real_escape_string($koneksi, $_POST['jenis']);
$satuan = mysqli_real_escape_string($koneksi, $_POST['satuan']);
mysqli_query($koneksi,"UPDATE tb_jenis SET jenis='$jenis',satuan='$satuan' WHERE kode_jenis='$kd'");
header("location:data_jenis.php?pesan=update");
exit();
?>
