<?php
include 'koneksi.php';
$kd = mysqli_real_escape_string($koneksi, $_GET['kd']);
mysqli_query($koneksi,"DELETE FROM tb_barang WHERE kd_barang='$kd'");
header("location:data_barang.php?pesan=hapus");
exit();
?>
