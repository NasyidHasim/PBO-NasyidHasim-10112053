<?php
include 'koneksi.php';
$kd      = mysqli_real_escape_string($koneksi, $_POST['kd_barang']);
$jenis   = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
$nama    = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
$stok    = (int)$_POST['stok'];
$hbeli   = (int)$_POST['harga_beli'];
$hjual   = (int)$_POST['harga_jual'];
$gambar  = mysqli_real_escape_string($koneksi, $_POST['gambar_produk']);
mysqli_query($koneksi,"INSERT INTO tb_barang (kd_barang,kode_jenis,nama_barang,stok,harga_beli,harga_jual,gambar_produk) VALUES ('$kd','$jenis','$nama','$stok','$hbeli','$hjual','$gambar')");
header("location:data_barang.php?pesan=input");
exit();
?>
