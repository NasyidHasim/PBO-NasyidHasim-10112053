-- =============================================
-- DATABASE: db_inventory
-- =============================================
CREATE DATABASE IF NOT EXISTS db_inventory;
USE db_inventory;

-- Tabel user (admin login)
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tipe_user` varchar(50) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`username`, `password`, `tipe_user`) VALUES
('admin', 'admin123', 'Admin');

-- Tabel tb_jenis
CREATE TABLE IF NOT EXISTS `tb_jenis` (
  `kode_jenis` varchar(20) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `satuan` varchar(30) NOT NULL,
  PRIMARY KEY (`kode_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tb_jenis` (`kode_jenis`, `jenis`, `satuan`) VALUES
('JNS001', 'Elektronik', 'Unit'),
('JNS002', 'Makanan', 'Kg'),
('JNS003', 'Minuman', 'Liter'),
('JNS004', 'Pakaian', 'Pcs');

-- Tabel tb_barang
CREATE TABLE IF NOT EXISTS `tb_barang` (
  `kd_barang` varchar(100) NOT NULL,
  `kode_jenis` varchar(20) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `harga_beli` int(11) NOT NULL DEFAULT 0,
  `harga_jual` int(11) NOT NULL DEFAULT 0,
  `gambar_produk` text,
  PRIMARY KEY (`kd_barang`),
  KEY `kode_jenis` (`kode_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Tabel tb_supplier
CREATE TABLE IF NOT EXISTS `tb_supplier` (
  `id_supplier` varchar(100) NOT NULL,
  `nama_supplier` text NOT NULL,
  `alamat_supplier` text,
  `telepon_supplier` varchar(100),
  `email_supplier` varchar(100),
  `pass_supplier` varchar(100),
  PRIMARY KEY (`id_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tb_supplier` VALUES
('SUP001','PT Maju Jaya','Jl. Sudirman No. 1, Jakarta','08111000001','maju@email.com','sup123'),
('SUP002','CV Berkah Abadi','Jl. Gatot Subroto No. 5, Bandung','08111000002','berkah@email.com','sup456');

-- Tabel tb_customer
CREATE TABLE IF NOT EXISTS `tb_customer` (
  `id_customer` varchar(100) NOT NULL,
  `nama_customer` text NOT NULL,
  `jenis_kelamin` varchar(100),
  `alamat_customer` text,
  `telepon_customer` varchar(100),
  `email_customer` varchar(100),
  `pass_customer` varchar(100),
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tb_customer` VALUES
('CS001','Budi Santoso','Laki-laki','Jl. Merdeka No. 10, Jakarta','08222000001','budi@email.com','cs123'),
('CS002','Siti Rahayu','Perempuan','Jl. Pahlawan No. 3, Surabaya','08222000002','siti@email.com','cs456');

-- Tabel tb_pembelian
CREATE TABLE IF NOT EXISTS `tb_pembelian` (
  `no_pembelian` varchar(100) NOT NULL,
  `tanggal_pembelian` varchar(30) NOT NULL,
  `id_supplier` varchar(100) NOT NULL,
  `total_barangall` int(30) NOT NULL DEFAULT 0,
  `total_hargaall` int(30) NOT NULL DEFAULT 0,
  PRIMARY KEY (`no_pembelian`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Tabel detail_pembelian
CREATE TABLE IF NOT EXISTS `detail_pembelian` (
  `no_pembelian` varchar(30) NOT NULL,
  `kd_barang` varchar(100) NOT NULL,
  `kode_jenis` varchar(50),
  `jumlah_barang` int(30) NOT NULL DEFAULT 0,
  `harga_barang` int(30) NOT NULL DEFAULT 0,
  `total_harga` int(100) NOT NULL DEFAULT 0,
  `no_item` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`no_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Tabel tb_penjualan
CREATE TABLE IF NOT EXISTS `tb_penjualan` (
  `no_penjualan` varchar(30) NOT NULL,
  `tanggal_penjualan` varchar(30) NOT NULL,
  `id_customer` varchar(100) NOT NULL,
  `total_barangall` int(30) NOT NULL DEFAULT 0,
  `total_hargaall` int(30) NOT NULL DEFAULT 0,
  PRIMARY KEY (`no_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Tabel detail_penjualan
CREATE TABLE IF NOT EXISTS `detail_penjualan` (
  `no_penjualan` varchar(30) NOT NULL,
  `kd_barang` varchar(100) NOT NULL,
  `kode_jenis` varchar(30),
  `jumlah_barang` int(30) NOT NULL DEFAULT 0,
  `harga_barang` int(30) NOT NULL DEFAULT 0,
  `total_harga` int(100) NOT NULL DEFAULT 0,
  `no_item` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`no_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
