<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Laporan Data Supplier</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print">
        <button onclick="window.print()" class="btn-info"> Cetak Laporan</button>
    </div>
    <div class="card">
        <h3> Laporan Data Supplier — <?= date('d/m/Y') ?></h3>
        <table class="table">
            <tr><th>No</th><th>ID</th><th>Nama Supplier</th><th>No. Telepon</th><th>Email</th><th>Alamat</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT * FROM tb_supplier ORDER BY id_supplier");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['id_supplier'] ?></td>
                <td style="text-align:left"><?= $d['nama_supplier'] ?></td>
                <td><?= $d['telepon_supplier'] ?></td>
                <td><?= $d['email_supplier'] ?></td>
                <td style="text-align:left"><?= $d['alamat_supplier'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <p style="margin-top:10px;color:#666">Total Supplier: <?= mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_supplier")) ?></p>
    </div>
</div>
</body>
</html>
