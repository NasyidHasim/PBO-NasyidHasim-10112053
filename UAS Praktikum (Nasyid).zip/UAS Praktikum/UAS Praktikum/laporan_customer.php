<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Customer</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Laporan Data Customer</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print">
        <button onclick="window.print()" class="btn-info"> Cetak Laporan</button>
    </div>
    <div class="card">
        <h3> Laporan Data Customer — <?= date('d/m/Y') ?></h3>
        <table class="table">
            <tr><th>No</th><th>ID</th><th>Nama Customer</th><th>Jenis Kelamin</th><th>No. Telepon</th><th>Email</th><th>Alamat</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT * FROM tb_customer ORDER BY id_customer");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['id_customer'] ?></td>
                <td style="text-align:left"><?= $d['nama_customer'] ?></td>
                <td><?= $d['jenis_kelamin'] ?></td>
                <td><?= $d['telepon_customer'] ?></td>
                <td><?= $d['email_customer'] ?></td>
                <td style="text-align:left"><?= $d['alamat_customer'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <p style="margin-top:10px;color:#666">Total Customer: <?= mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tb_customer")) ?></p>
    </div>
</div>
</body>
</html>
