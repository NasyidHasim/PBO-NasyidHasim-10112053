<?php
include 'koneksi.php';
$id    = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
$nama  = mysqli_real_escape_string($koneksi, $_POST['nama_supplier']);
$adr   = mysqli_real_escape_string($koneksi, $_POST['alamat_supplier']);
$telp  = mysqli_real_escape_string($koneksi, $_POST['telepon_supplier']);
$email = mysqli_real_escape_string($koneksi, $_POST['email_supplier']);
$pass  = mysqli_real_escape_string($koneksi, $_POST['pass_supplier']);
mysqli_query($koneksi,"UPDATE tb_supplier SET nama_supplier='$nama',alamat_supplier='$adr',telepon_supplier='$telp',email_supplier='$email',pass_supplier='$pass' WHERE id_supplier='$id'");
header("location:data_supplier.php?pesan=update");
exit();
?>
