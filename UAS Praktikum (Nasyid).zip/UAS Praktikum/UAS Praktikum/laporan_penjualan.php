<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Transaksi Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Laporan Transaksi Penjualan</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print">
        <form method="get" style="display:inline-flex;gap:10px;align-items:center">
            <label>Filter Bulan:</label>
            <input type="month" name="bulan" value="<?= isset($_GET['bulan'])?$_GET['bulan']:date('Y-m') ?>">
            <input type="submit" value=" Filter" class="btn-primary" style="padding:6px 14px">
            <a href="laporan_penjualan.php" class="tombol btn-secondary" style="padding:6px 14px">Reset</a>
        </form>
        &nbsp;&nbsp;
        <button onclick="window.print()" class="btn-info"> Cetak</button>
    </div>
    <div class="card">
        <?php
        $where = '';
        if(isset($_GET['bulan']) && $_GET['bulan']){
            $bln = mysqli_real_escape_string($koneksi, $_GET['bulan']);
            $where = "WHERE p.tanggal_penjualan LIKE '$bln%'";
            echo "<h3> Laporan Penjualan: ".date('F Y', strtotime($bln.'-01'))."</h3>";
        } else {
            echo "<h3> Laporan Seluruh Transaksi Penjualan</h3>";
        }
        $q = mysqli_query($koneksi,"SELECT p.*, c.nama_customer FROM tb_penjualan p LEFT JOIN tb_customer c ON p.id_customer=c.id_customer $where ORDER BY p.tanggal_penjualan DESC");
        $total_hrg=0; $total_brg=0;
        $rows = [];
        while($d = mysqli_fetch_array($q)) { $rows[]=$d; $total_hrg+=$d['total_hargaall']; $total_brg+=$d['total_barangall']; }
        ?>
        <table class="table">
            <tr><th>No</th><th>No. Penjualan</th><th>Tanggal</th><th>Customer</th><th>Total Barang</th><th>Total Harga</th></tr>
            <?php $no=1; foreach($rows as $d): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['no_penjualan'] ?></td>
                <td><?= $d['tanggal_penjualan'] ?></td>
                <td style="text-align:left"><?= $d['nama_customer'] ?></td>
                <td><?= $d['total_barangall'] ?></td>
                <td>Rp <?= number_format($d['total_hargaall'],0,',','.') ?></td>
            </tr>
            <?php endforeach; ?>
            <tr style="background:#3d8b8b;color:#fff;font-weight:bold">
                <td colspan="4" style="text-align:right;padding-right:12px">TOTAL</td>
                <td><?= $total_brg ?></td>
                <td>Rp <?= number_format($total_hrg,0,',','.') ?></td>
            </tr>
        </table>
    </div>
</div>
</body>
</html>
