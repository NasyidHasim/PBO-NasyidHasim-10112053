<?php
include 'koneksi.php';
$id = mysqli_real_escape_string($koneksi, $_GET['id']);
mysqli_query($koneksi,"DELETE FROM tb_supplier WHERE id_supplier='$id'");
header("location:data_supplier.php?pesan=hapus");
exit();
?>
