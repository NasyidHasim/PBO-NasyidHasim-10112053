<?php
include 'koneksi.php';
$kd     = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
$jenis  = mysqli_real_escape_string($koneksi, $_POST['jenis']);
$satuan = mysqli_real_escape_string($koneksi, $_POST['satuan']);
mysqli_query($koneksi,"INSERT INTO tb_jenis VALUES ('$kd','$jenis','$satuan')");
header("location:data_jenis.php?pesan=input");
exit();
?>
