<?php
include 'koneksi.php';
$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);
mysqli_query($koneksi,"INSERT INTO user (username, password, tipe_user) VALUES ('$username','$password','Admin')");
header("location:data_user.php?pesan=input");
exit();
?>
