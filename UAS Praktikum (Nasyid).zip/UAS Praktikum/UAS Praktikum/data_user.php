<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data User - Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1> Aplikasi Gudang</h1>
    <h2>Halaman Data User</h2>
</div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Data berhasil ditambahkan!';
        elseif($_GET['pesan']=='update') echo ' Data berhasil diperbarui!';
        elseif($_GET['pesan']=='hapus') echo ' Data berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <h3> Data Admin</h3>
        <button onclick="location.href='input_user.php'" class="btn-primary" style="margin-bottom:12px">+ Tambah Admin</button>
        <table class="table">
            <tr><th>No</th><th>Username</th><th>Tipe User</th><th>Aksi</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT * FROM user WHERE tipe_user='Admin'");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['username'] ?></td>
                <td><?= $d['tipe_user'] ?></td>
                <td>
                    <a class="edit" href="edit_admin.php?id=<?= $d['id_user'] ?>"> Edit</a>
                    <a class="hapus" href="hapus_user.php?id=<?= $d['id_user'] ?>" onclick="return confirm('Yakin hapus data ini?')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
