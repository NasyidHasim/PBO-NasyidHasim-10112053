<?php
include "koneksi.php";
$id = mysqli_real_escape_string($koneksi, $_GET['id']);
$q = mysqli_query($koneksi,"SELECT * FROM tb_customer WHERE id_customer='$id'");
$data = mysqli_fetch_array($q);
if(!$data) { header("location:data_customer.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Edit Data Customer</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3> Form Edit Customer</h3>
        <a href="data_customer.php" class="tombol btn-secondary"> Kembali</a><br><br>
        <form action="update_customer.php" method="post">
            <input type="hidden" name="id_customer" value="<?= $data['id_customer'] ?>">
            <table class="table-form">
                <tr><td>ID Customer</td><td>:</td><td><input type="text" value="<?= $data['id_customer'] ?>" disabled style="background:#eee"></td></tr>
                <tr><td>Nama Customer</td><td>:</td><td><input type="text" name="nama_customer" value="<?= $data['nama_customer'] ?>" required></td></tr>
                <tr>
                    <td>Jenis Kelamin</td><td>:</td>
                    <td>
                        <select name="jenis_kelamin" required>
                            <option value="Laki-laki" <?= $data['jenis_kelamin']=='Laki-laki'?'selected':'' ?>>Laki-laki</option>
                            <option value="Perempuan" <?= $data['jenis_kelamin']=='Perempuan'?'selected':'' ?>>Perempuan</option>
                        </select>
                    </td>
                </tr>
                <tr><td>Alamat</td><td>:</td><td><textarea name="alamat_customer" rows="3" required><?= $data['alamat_customer'] ?></textarea></td></tr>
                <tr><td>No. Telepon</td><td>:</td><td><input type="text" name="telepon_customer" value="<?= $data['telepon_customer'] ?>" required></td></tr>
                <tr><td>Email</td><td>:</td><td><input type="email" name="email_customer" value="<?= $data['email_customer'] ?>"></td></tr>
                <tr><td>Password</td><td>:</td><td><input type="password" name="pass_customer" value="<?= $data['pass_customer'] ?>" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Perubahan"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
