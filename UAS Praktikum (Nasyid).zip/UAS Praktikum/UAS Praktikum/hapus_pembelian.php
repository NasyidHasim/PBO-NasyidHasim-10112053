<?php
include 'koneksi.php';
$no = mysqli_real_escape_string($koneksi, $_GET['no']);
// Kembalikan stok
$details = mysqli_query($koneksi,"SELECT * FROM detail_pembelian WHERE no_pembelian='$no'");
while($d = mysqli_fetch_array($details)){
    $kd  = mysqli_real_escape_string($koneksi, $d['kd_barang']);
    $jml = (int)$d['jumlah_barang'];
    mysqli_query($koneksi,"UPDATE tb_barang SET stok=stok-$jml WHERE kd_barang='$kd'");
}
mysqli_query($koneksi,"DELETE FROM detail_pembelian WHERE no_pembelian='$no'");
mysqli_query($koneksi,"DELETE FROM tb_pembelian WHERE no_pembelian='$no'");
header("location:transaksi_pembelian.php?pesan=hapus");
exit();
?>
