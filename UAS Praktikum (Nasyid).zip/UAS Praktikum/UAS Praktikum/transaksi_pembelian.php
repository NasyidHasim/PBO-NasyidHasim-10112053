<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Pembelian</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Transaksi Pembelian</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Transaksi pembelian berhasil disimpan!';
        elseif($_GET['pesan']=='hapus') echo ' Transaksi berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <h3> Daftar Transaksi Pembelian</h3>
        <button onclick="location.href='input_pembelian.php'" class="btn-success" style="margin-bottom:12px"> Buat Transaksi Baru</button>
        <table class="table">
            <tr><th>No</th><th>No. Pembelian</th><th>Tanggal</th><th>Supplier</th><th>Total Barang</th><th>Total Harga</th><th>Aksi</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT p.*, s.nama_supplier FROM tb_pembelian p LEFT JOIN tb_supplier s ON p.id_supplier=s.id_supplier ORDER BY p.no_pembelian DESC");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['no_pembelian'] ?></td>
                <td><?= $d['tanggal_pembelian'] ?></td>
                <td style="text-align:left"><?= $d['nama_supplier'] ?></td>
                <td><?= $d['total_barangall'] ?></td>
                <td>Rp <?= number_format($d['total_hargaall'],0,',','.') ?></td>
                <td>
                    <a class="detail" href="detail_pembelian.php?no=<?= $d['no_pembelian'] ?>"> Detail</a>
                    <a class="hapus" href="hapus_pembelian.php?no=<?= $d['no_pembelian'] ?>" onclick="return confirm('Yakin hapus transaksi ini? Stok barang akan dikembalikan.')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
