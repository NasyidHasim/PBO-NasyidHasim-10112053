<?php
include 'koneksi.php';
$no      = mysqli_real_escape_string($koneksi, $_POST['no_pembelian']);
$tgl     = mysqli_real_escape_string($koneksi, $_POST['tanggal_pembelian']);
$sup     = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
$ttl_brg = (int)$_POST['total_barangall'];
$ttl_hrg = (int)$_POST['total_hargaall'];

mysqli_query($koneksi,"INSERT INTO tb_pembelian VALUES ('$no','$tgl','$sup','$ttl_brg','$ttl_hrg')");

$kd_arr    = $_POST['kd_barang'];
$jns_arr   = $_POST['kode_jenis'];
$jml_arr   = $_POST['jumlah_barang'];
$hrg_arr   = $_POST['harga_barang'];

for($i=0; $i<count($kd_arr); $i++){
    if(empty($kd_arr[$i])) continue;
    $kd  = mysqli_real_escape_string($koneksi, $kd_arr[$i]);
    $jns = mysqli_real_escape_string($koneksi, $jns_arr[$i]);
    $jml = (int)$jml_arr[$i];
    $hrg = (int)$hrg_arr[$i];
    $sub = $jml * $hrg;
    mysqli_query($koneksi,"INSERT INTO detail_pembelian (no_pembelian,kd_barang,kode_jenis,jumlah_barang,harga_barang,total_harga) VALUES ('$no','$kd','$jns','$jml','$hrg','$sub')");
    // Update stok
    mysqli_query($koneksi,"UPDATE tb_barang SET stok=stok+$jml WHERE kd_barang='$kd'");
}

header("location:transaksi_pembelian.php?pesan=input");
exit();
?>
