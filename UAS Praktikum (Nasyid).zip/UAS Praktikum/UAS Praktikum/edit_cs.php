<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Customer / Supplier</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <h1>Sistem Inventory Sederhana</h1>
        <h2>Edit Data Customer / Supplier</h2>
    </div>

    <br/>
    <a href="data_user.php" class="tombol"> Kembali ke Data Master</a>
    <br/><br/>

    <h3>Form Edit Data</h3>

    <?php
    include "koneksi.php";
    $id = (int) $_GET['id'];
    $query_mysql = mysqli_query($koneksi, "SELECT * FROM user WHERE id='$id'");
    
    while($data = mysqli_fetch_array($query_mysql)){
    ?>
        <form action="update_cs.php" method="post">
            
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
            
            <table class="table-form">
                <tr>
                    <td>Username</td>
                    <td>:</td>
                    <td><input type="text" name="username" value="<?php echo $data['username']; ?>" placeholder="Masukkan username" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td>:</td>
                    <td><input type="text" name="password" value="<?php echo $data['password']; ?>" placeholder="Masukkan password" required></td>
                </tr>
                <tr>
                    <td>No. Telepon</td>
                    <td>:</td>
                    <td><input type="number" name="telepon" value="<?php echo $data['telepon']; ?>" placeholder="Masukkan nomor telepon" required></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><textarea name="alamat" placeholder="Masukkan alamat lengkap" rows="3" style="width: 100%;" required><?php echo $data['alamat']; ?></textarea></td>
                </tr>
                <tr>
                    <td>Tipe User</td>
                    <td>:</td>
                    <td>
                        <select name="tipe_user" required>
                            <option value="">-- Pilih Tipe --</option>
                            <option value="Customer" <?php if($data['tipe_user'] == 'Customer') echo 'selected'; ?>>Customer</option>
                            <option value="Supplier" <?php if($data['tipe_user'] == 'Supplier') echo 'selected'; ?>>Supplier</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>
                        <input type="submit" value="Simpan Perubahan">
                    </td>
                </tr>
            </table>
        </form>
    <?php } ?>
</body>
</html>