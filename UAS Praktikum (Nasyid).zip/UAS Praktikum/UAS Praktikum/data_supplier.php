<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Supplier - Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Data Supplier</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Supplier berhasil ditambahkan!';
        elseif($_GET['pesan']=='update') echo ' Supplier berhasil diperbarui!';
        elseif($_GET['pesan']=='hapus') echo ' Supplier berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>
    <div class="card">
        <h3> Daftar Supplier</h3>
        <button onclick="location.href='input_supplier.php'" class="btn-success" style="margin-bottom:12px">+ Tambah Supplier</button>
        <table class="table">
            <tr><th>No</th><th>ID</th><th>Nama Supplier</th><th>Telepon</th><th>Email</th><th>Alamat</th><th>Aksi</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT * FROM tb_supplier ORDER BY id_supplier ASC");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['id_supplier'] ?></td>
                <td style="text-align:left"><?= $d['nama_supplier'] ?></td>
                <td><?= $d['telepon_supplier'] ?></td>
                <td><?= $d['email_supplier'] ?></td>
                <td style="text-align:left"><?= $d['alamat_supplier'] ?></td>
                <td>
                    <a class="edit" href="edit_supplier.php?id=<?= $d['id_supplier'] ?>"> Edit</a>
                    <a class="hapus" href="hapus_supplier.php?id=<?= $d['id_supplier'] ?>" onclick="return confirm('Yakin hapus supplier ini?')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
