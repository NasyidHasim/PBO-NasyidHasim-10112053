<?php
include 'koneksi.php';
$no = mysqli_real_escape_string($koneksi, $_GET['no']);
$details = mysqli_query($koneksi,"SELECT * FROM detail_penjualan WHERE no_penjualan='$no'");
while($d = mysqli_fetch_array($details)){
    $kd  = mysqli_real_escape_string($koneksi, $d['kd_barang']);
    $jml = (int)$d['jumlah_barang'];
    mysqli_query($koneksi,"UPDATE tb_barang SET stok=stok+$jml WHERE kd_barang='$kd'");
}
mysqli_query($koneksi,"DELETE FROM detail_penjualan WHERE no_penjualan='$no'");
mysqli_query($koneksi,"DELETE FROM tb_penjualan WHERE no_penjualan='$no'");
header("location:transaksi_penjualan.php?pesan=hapus");
exit();
?>
