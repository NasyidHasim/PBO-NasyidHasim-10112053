<?php
include 'koneksi.php';
$id = (int) $_POST['id'];
$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);
mysqli_query($koneksi,"UPDATE user SET username='$username', password='$password' WHERE id_user='$id'");
header("location:data_user.php?pesan=update");
exit();
?>
