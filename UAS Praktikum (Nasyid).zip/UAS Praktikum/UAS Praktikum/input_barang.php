<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Tambah Data Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>➕ Form Tambah Barang</h3>
        <a href="data_barang.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="input_aksi_barang.php" method="post">
            <table class="table-form">
                <tr>
                    <td>Kode Barang</td><td>:</td>
                    <td><input type="text" name="kd_barang" placeholder="Cth: BRG001" required></td>
                </tr>
                <tr>
                    <td>Jenis Barang</td><td>:</td>
                    <td>
                        <select name="kode_jenis" required>
                            <option value="">-- Pilih Jenis --</option>
                            <?php
                            $qj = mysqli_query($koneksi,"SELECT * FROM tb_jenis");
                            while($j = mysqli_fetch_array($qj)):
                            ?>
                            <option value="<?= $j['kode_jenis'] ?>"><?= $j['jenis'] ?> (<?= $j['satuan'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Nama Barang</td><td>:</td>
                    <td><input type="text" name="nama_barang" placeholder="Masukkan nama barang" required></td>
                </tr>
                <tr>
                    <td>Stok Awal</td><td>:</td>
                    <td><input type="number" name="stok" placeholder="0" min="0" required></td>
                </tr>
                <tr>
                    <td>Harga Beli (Rp)</td><td>:</td>
                    <td><input type="number" name="harga_beli" placeholder="0" min="0" required></td>
                </tr>
                <tr>
                    <td>Harga Jual (Rp)</td><td>:</td>
                    <td><input type="number" name="harga_jual" placeholder="0" min="0" required></td>
                </tr>
                <tr>
                    <td>Gambar Produk</td><td>:</td>
                    <td><input type="text" name="gambar_produk" placeholder="Nama file gambar (opsional)"></td>
                </tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Barang"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
