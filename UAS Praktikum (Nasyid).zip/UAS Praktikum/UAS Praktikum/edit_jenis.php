<?php
include "koneksi.php";
$kd = mysqli_real_escape_string($koneksi, $_GET['kd']);
$q = mysqli_query($koneksi,"SELECT * FROM tb_jenis WHERE kode_jenis='$kd'");
$data = mysqli_fetch_array($q);
if(!$data) { header("location:data_jenis.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head><title>Edit Jenis</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Edit Jenis Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>✏️ Form Edit Jenis</h3>
        <a href="data_jenis.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="update_jenis.php" method="post">
            <input type="hidden" name="kode_jenis" value="<?= $data['kode_jenis'] ?>">
            <table class="table-form">
                <tr><td>Kode Jenis</td><td>:</td><td><input type="text" value="<?= $data['kode_jenis'] ?>" disabled style="background:#eee"></td></tr>
                <tr><td>Nama Jenis</td><td>:</td><td><input type="text" name="jenis" value="<?= $data['jenis'] ?>" required></td></tr>
                <tr><td>Satuan</td><td>:</td><td><input type="text" name="satuan" value="<?= $data['satuan'] ?>" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Perubahan"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
