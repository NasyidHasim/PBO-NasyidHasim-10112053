<?php
include 'koneksi.php';
$kd_lama = mysqli_real_escape_string($koneksi, $_POST['kd_barang_lama']);
$kd      = mysqli_real_escape_string($koneksi, $_POST['kd_barang']);
$jenis   = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
$nama    = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
$stok    = (int)$_POST['stok'];
$hbeli   = (int)$_POST['harga_beli'];
$hjual   = (int)$_POST['harga_jual'];
$gambar  = mysqli_real_escape_string($koneksi, $_POST['gambar_produk']);
mysqli_query($koneksi,"UPDATE tb_barang SET kd_barang='$kd',kode_jenis='$jenis',nama_barang='$nama',stok='$stok',harga_beli='$hbeli',harga_jual='$hjual',gambar_produk='$gambar' WHERE kd_barang='$kd_lama'");
header("location:data_barang.php?pesan=update");
exit();
?>
