<?php
include "koneksi.php";
$id = mysqli_real_escape_string($koneksi, $_GET['id']);
$q = mysqli_query($koneksi,"SELECT * FROM tb_supplier WHERE id_supplier='$id'");
$data = mysqli_fetch_array($q);
if(!$data) { header("location:data_supplier.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Edit Data Supplier</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>✏️ Form Edit Supplier</h3>
        <a href="data_supplier.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="update_supplier.php" method="post">
            <input type="hidden" name="id_supplier" value="<?= $data['id_supplier'] ?>">
            <table class="table-form">
                <tr><td>ID Supplier</td><td>:</td><td><input type="text" value="<?= $data['id_supplier'] ?>" disabled style="background:#eee"></td></tr>
                <tr><td>Nama Supplier</td><td>:</td><td><input type="text" name="nama_supplier" value="<?= $data['nama_supplier'] ?>" required></td></tr>
                <tr><td>Alamat</td><td>:</td><td><textarea name="alamat_supplier" rows="3" required><?= $data['alamat_supplier'] ?></textarea></td></tr>
                <tr><td>No. Telepon</td><td>:</td><td><input type="text" name="telepon_supplier" value="<?= $data['telepon_supplier'] ?>" required></td></tr>
                <tr><td>Email</td><td>:</td><td><input type="email" name="email_supplier" value="<?= $data['email_supplier'] ?>"></td></tr>
                <tr><td>Password</td><td>:</td><td><input type="password" name="pass_supplier" value="<?= $data['pass_supplier'] ?>" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Perubahan"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
