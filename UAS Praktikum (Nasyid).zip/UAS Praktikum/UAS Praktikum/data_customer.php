<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Customer - Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Data Customer</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Customer berhasil ditambahkan!';
        elseif($_GET['pesan']=='update') echo ' Customer berhasil diperbarui!';
        elseif($_GET['pesan']=='hapus') echo ' Customer berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>
    <div class="card">
        <h3> Daftar Customer</h3>
        <button onclick="location.href='input_customer.php'" class="btn-success" style="margin-bottom:12px">+ Tambah Customer</button>
        <table class="table">
            <tr><th>No</th><th>ID</th><th>Nama</th><th>Jenis Kelamin</th><th>Telepon</th><th>Email</th><th>Alamat</th><th>Aksi</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT * FROM tb_customer ORDER BY id_customer ASC");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['id_customer'] ?></td>
                <td style="text-align:left"><?= $d['nama_customer'] ?></td>
                <td><?= $d['jenis_kelamin'] ?></td>
                <td><?= $d['telepon_customer'] ?></td>
                <td><?= $d['email_customer'] ?></td>
                <td style="text-align:left"><?= $d['alamat_customer'] ?></td>
                <td>
                    <a class="edit" href="edit_customer.php?id=<?= $d['id_customer'] ?>"> Edit</a>
                    <a class="hapus" href="hapus_customer.php?id=<?= $d['id_customer'] ?>" onclick="return confirm('Yakin hapus customer ini?')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
