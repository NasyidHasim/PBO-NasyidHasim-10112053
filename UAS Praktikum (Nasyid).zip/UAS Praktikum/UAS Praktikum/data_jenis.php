<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Jenis Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Data Jenis Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Jenis berhasil ditambahkan!';
        elseif($_GET['pesan']=='update') echo ' Jenis berhasil diperbarui!';
        elseif($_GET['pesan']=='hapus') echo ' Jenis berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>
    <div class="card">
        <h3>Daftar Jenis Barang</h3>
        <button onclick="location.href='input_jenis.php'" class="btn-success" style="margin-bottom:12px">+ Tambah Jenis</button>
        <table class="table">
            <tr><th>No</th><th>Kode Jenis</th><th>Nama Jenis</th><th>Satuan</th><th>Aksi</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT * FROM tb_jenis ORDER BY kode_jenis ASC");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['kode_jenis'] ?></td>
                <td><?= $d['jenis'] ?></td>
                <td><?= $d['satuan'] ?></td>
                <td>
                    <a class="edit" href="edit_jenis.php?kd=<?= $d['kode_jenis'] ?>"> Edit</a>
                    <a class="hapus" href="hapus_jenis.php?kd=<?= $d['kode_jenis'] ?>" onclick="return confirm('Yakin hapus jenis ini?')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
