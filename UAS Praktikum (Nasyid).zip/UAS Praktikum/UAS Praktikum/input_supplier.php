<!DOCTYPE html>
<html>
<head>
    <title>Tambah Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Tambah Data Supplier</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>➕ Form Tambah Supplier</h3>
        <a href="data_supplier.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="input_aksi_supplier.php" method="post">
            <table class="table-form">
                <tr><td>ID Supplier</td><td>:</td><td><input type="text" name="id_supplier" placeholder="Cth: SUP003" required></td></tr>
                <tr><td>Nama Supplier</td><td>:</td><td><input type="text" name="nama_supplier" placeholder="Masukkan nama supplier" required></td></tr>
                <tr><td>Alamat</td><td>:</td><td><textarea name="alamat_supplier" rows="3" placeholder="Masukkan alamat" required></textarea></td></tr>
                <tr><td>No. Telepon</td><td>:</td><td><input type="text" name="telepon_supplier" placeholder="08xxxxxxxxxx" required></td></tr>
                <tr><td>Email</td><td>:</td><td><input type="email" name="email_supplier" placeholder="email@example.com"></td></tr>
                <tr><td>Password</td><td>:</td><td><input type="password" name="pass_supplier" placeholder="Masukkan password" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value="💾 Simpan Supplier"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
