<?php
include "koneksi.php";
$id = (int) $_GET['id'];
$q = mysqli_query($koneksi,"SELECT * FROM user WHERE id_user='$id'");
$data = mysqli_fetch_array($q);
if(!$data) { header("location:data_user.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Edit Data Admin</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3> Form Edit Admin</h3>
        <a href="data_user.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="update_admin.php" method="post">
            <input type="hidden" name="id" value="<?= $data['id_user'] ?>">
            <table class="table-form">
                <tr><td>Username</td><td>:</td><td><input type="text" name="username" value="<?= $data['username'] ?>" required></td></tr>
                <tr><td>Password</td><td>:</td><td><input type="password" name="password" value="<?= $data['password'] ?>" required></td></tr>
                <tr><td></td><td></td><td><input type="submit" value=" Simpan Perubahan"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
