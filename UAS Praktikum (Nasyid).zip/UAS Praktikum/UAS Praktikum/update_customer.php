<?php
include 'koneksi.php';
$id     = mysqli_real_escape_string($koneksi, $_POST['id_customer']);
$nama   = mysqli_real_escape_string($koneksi, $_POST['nama_customer']);
$jk     = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
$alamat = mysqli_real_escape_string($koneksi, $_POST['alamat_customer']);
$telp   = mysqli_real_escape_string($koneksi, $_POST['telepon_customer']);
$email  = mysqli_real_escape_string($koneksi, $_POST['email_customer']);
$pass   = mysqli_real_escape_string($koneksi, $_POST['pass_customer']);
mysqli_query($koneksi,"UPDATE tb_customer SET nama_customer='$nama',jenis_kelamin='$jk',alamat_customer='$alamat',telepon_customer='$telp',email_customer='$email',pass_customer='$pass' WHERE id_customer='$id'");
header("location:data_customer.php?pesan=update");
exit();
?>
