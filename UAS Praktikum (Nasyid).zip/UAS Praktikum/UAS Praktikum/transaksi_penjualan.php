<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Transaksi Penjualan</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Transaksi penjualan berhasil disimpan!';
        elseif($_GET['pesan']=='hapus') echo ' Transaksi berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>
    <div class="card">
        <h3> Daftar Transaksi Penjualan</h3>
        <button onclick="location.href='input_penjualan.php'" class="btn-success" style="margin-bottom:12px"> Buat Transaksi Baru</button>
        <table class="table">
            <tr><th>No</th><th>No. Penjualan</th><th>Tanggal</th><th>Customer</th><th>Total Barang</th><th>Total Harga</th><th>Aksi</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT p.*, c.nama_customer FROM tb_penjualan p LEFT JOIN tb_customer c ON p.id_customer=c.id_customer ORDER BY p.no_penjualan DESC");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['no_penjualan'] ?></td>
                <td><?= $d['tanggal_penjualan'] ?></td>
                <td style="text-align:left"><?= $d['nama_customer'] ?></td>
                <td><?= $d['total_barangall'] ?></td>
                <td>Rp <?= number_format($d['total_hargaall'],0,',','.') ?></td>
                <td>
                    <a class="detail" href="detail_penjualan.php?no=<?= $d['no_penjualan'] ?>"> Detail</a>
                    <a class="hapus" href="hapus_penjualan.php?no=<?= $d['no_penjualan'] ?>" onclick="return confirm('Yakin hapus transaksi ini? Stok barang akan dikembalikan.')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
