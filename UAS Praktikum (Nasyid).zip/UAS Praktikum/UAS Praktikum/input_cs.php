<?php
// Redirect ke halaman input yang sesuai
header("location:input_customer.php");
exit();
?>
