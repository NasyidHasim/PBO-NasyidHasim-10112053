<?php
// Redirect ke aksi customer yang benar
header("location:input_aksi_customer.php");
exit();
?>
