<?php $halaman_aktif = basename($_SERVER['PHP_SELF']); ?>
<ul class="navbar">
    <li><a href="index.php" <?php if($halaman_aktif=='index.php') echo 'class="active"'; ?>> Home</a></li>
    <li class="dropdown">
        <a href="#" class="dropbtn"> Data Master</a>
        <div class="dropdown-content">
            <a href="data_user.php"> Data User / Admin</a>
            <a href="data_barang.php"> Data Barang</a>
            <a href="data_customer.php"> Data Customer</a>
            <a href="data_supplier.php"> Data Supplier</a>
            <a href="data_jenis.php"> Data Jenis Barang</a>
        </div>
    </li>
    <li class="dropdown">
        <a href="#" class="dropbtn"> Data Transaksi</a>
        <div class="dropdown-content">
            <a href="transaksi_pembelian.php"> Transaksi Pembelian</a>
            <a href="transaksi_penjualan.php"> Transaksi Penjualan</a>
        </div>
    </li>
    <li class="dropdown">
        <a href="#" class="dropbtn"> Laporan</a>
        <div class="dropdown-content">
            <a href="laporan_barang.php"> Laporan Data Barang</a>
            <a href="laporan_customer.php"> Laporan Data Customer</a>
            <a href="laporan_supplier.php"> Laporan Data Supplier</a>
            <a href="laporan_pembelian.php"> Laporan Transaksi Pembelian</a>
            <a href="laporan_penjualan.php"> Laporan Transaksi Penjualan</a>
        </div>
    </li>
</ul>
