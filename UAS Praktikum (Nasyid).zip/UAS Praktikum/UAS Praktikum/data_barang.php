<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Barang - Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Data Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <?php if(isset($_GET['pesan'])): ?>
    <div class="alert alert-success">
        <?php
        if($_GET['pesan']=='input') echo ' Barang berhasil ditambahkan!';
        elseif($_GET['pesan']=='update') echo ' Barang berhasil diperbarui!';
        elseif($_GET['pesan']=='hapus') echo ' Barang berhasil dihapus!';
        ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <h3> Daftar Barang</h3>
        <button onclick="location.href='input_barang.php'" class="btn-success" style="margin-bottom:12px"> Tambah Barang</button>
        <table class="table">
            <tr>
                <th>No</th><th>Kode</th><th>Nama Barang</th><th>Jenis</th>
                <th>Stok</th><th>Harga Beli</th><th>Harga Jual</th><th>Aksi</th>
            </tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT b.*, j.jenis, j.satuan FROM tb_barang b LEFT JOIN tb_jenis j ON b.kode_jenis=j.kode_jenis ORDER BY b.kd_barang ASC");
            $no=1;
            while($d = mysqli_fetch_array($q)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['kd_barang'] ?></td>
                <td style="text-align:left"><?= $d['nama_barang'] ?></td>
                <td><?= $d['jenis'] ?></td>
                <td style="<?= $d['stok']<=5 ? 'color:red;font-weight:bold' : '' ?>"><?= $d['stok'] ?> <?= $d['satuan'] ?></td>
                <td>Rp <?= number_format($d['harga_beli'],0,',','.') ?></td>
                <td>Rp <?= number_format($d['harga_jual'],0,',','.') ?></td>
                <td>
                    <a class="edit" href="edit_barang.php?kd=<?= $d['kd_barang'] ?>"> Edit</a>
                    <a class="hapus" href="hapus_barang.php?kd=<?= $d['kd_barang'] ?>" onclick="return confirm('Yakin hapus barang ini?')"> Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
