<!DOCTYPE html>
<html>
<head>
    <title>Login - Sistem Inventory</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
        <h1>Sistem Inventory Sederhana</h1>
        <h2>Silakan Login Terlebih Dahulu</h2>
    </div>

    <div class="container" style="max-width: 400px; margin: 0 auto; text-align: center;">
        <br/>
        
        <?php 
        if(isset($_GET['pesan'])){
            if($_GET['pesan'] == "gagal"){
                echo "<div style='color: red; margin-bottom: 10px;'>Login gagal! Username dan password salah!</div>";
            } else if($_GET['pesan'] == "logout"){
                echo "<div style='color: green; margin-bottom: 10px;'>Anda telah berhasil logout.</div>";
            } else if($_GET['pesan'] == "belum_login"){
                echo "<div style='color: orange; margin-bottom: 10px;'>Anda harus login untuk mengakses halaman tersebut.</div>";
            }
        }
        ?>

        <form action="cek_login.php" method="post">
            <table class="table-form" style="width: 100%;">
                <tr>
                    <td>Username</td>
                    <td>:</td>
                    <td><input type="text" name="username" placeholder="Masukkan username" required style="width: 100%;"></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td>:</td>
                    <td><input type="password" name="password" placeholder="Masukkan password" required style="width: 100%;"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>
                        <input type="submit" value="Login" style="width: 100%;">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>