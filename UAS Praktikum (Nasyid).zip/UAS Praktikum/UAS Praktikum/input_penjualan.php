<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Input Penjualan</title>
    <link rel="stylesheet" href="style.css">
    <style>
        #tabel-item { width:100%; border-collapse:collapse; margin-top:10px; }
        #tabel-item th { background:#3d8b8b; color:#fff; padding:8px; }
        #tabel-item td { border:1px solid #ddd; padding:7px; }
        #tabel-item input, #tabel-item select { width:100%; padding:5px; box-sizing:border-box; }
        .total-box { background:#e8f5f5; padding:14px; border-radius:6px; margin-top:12px; font-size:15px; }
    </style>
</head>
<body>
<div class="header"><h1>🏪 Aplikasi Gudang</h1><h2>Input Transaksi Penjualan</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3>💰 Form Transaksi Penjualan</h3>
        <a href="transaksi_penjualan.php" class="tombol btn-secondary">◀ Kembali</a><br><br>
        <form action="simpan_penjualan.php" method="post" id="formJual">
        <table class="table-form">
            <tr>
                <td>No. Penjualan</td><td>:</td>
                <td>
                <?php
                $last = mysqli_fetch_array(mysqli_query($koneksi,"SELECT no_penjualan FROM tb_penjualan ORDER BY no_penjualan DESC LIMIT 1"));
                $no_baru = 'PJ' . str_pad((isset($last['no_penjualan']) ? (int)substr($last['no_penjualan'],2)+1 : 1), 4, '0', STR_PAD_LEFT);
                ?>
                <input type="text" name="no_penjualan" value="<?= $no_baru ?>" required>
                </td>
            </tr>
            <tr>
                <td>Tanggal</td><td>:</td>
                <td><input type="date" name="tanggal_penjualan" value="<?= date('Y-m-d') ?>" required></td>
            </tr>
            <tr>
                <td>Customer</td><td>:</td>
                <td>
                    <select name="id_customer" required>
                        <option value="">-- Pilih Customer --</option>
                        <?php
                        $qc = mysqli_query($koneksi,"SELECT * FROM tb_customer");
                        while($c = mysqli_fetch_array($qc)):
                        ?>
                        <option value="<?= $c['id_customer'] ?>"><?= $c['nama_customer'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </td>
            </tr>
        </table>

        <br>
        <h4>📦 Daftar Barang yang Dijual</h4>
        <button type="button" onclick="tambahBaris()" class="btn-info">➕ Tambah Baris</button>
        <table id="tabel-item">
            <tr><th>Barang</th><th>Jenis</th><th>Stok</th><th>Jumlah</th><th>Harga Jual (Rp)</th><th>Subtotal</th><th>Hapus</th></tr>
            <tbody id="tbody-item"></tbody>
        </table>

        <div class="total-box">
            <b>Total Barang: <span id="ttl-brg">0</span> &nbsp;&nbsp; Total Harga: Rp <span id="ttl-hrg">0</span></b>
            <input type="hidden" name="total_barangall" id="inp-ttl-brg">
            <input type="hidden" name="total_hargaall" id="inp-ttl-hrg">
        </div>
        <br>
        <input type="submit" value="💾 Simpan Transaksi" class="btn-success" style="padding:10px 24px;font-size:15px">
        </form>
    </div>
</div>

<script>
var barangList = <?php
    $qb = mysqli_query($koneksi,"SELECT b.*, j.jenis FROM tb_barang b LEFT JOIN tb_jenis j ON b.kode_jenis=j.kode_jenis WHERE b.stok > 0");
    $arr=[];
    while($r=mysqli_fetch_assoc($qb)) $arr[]=$r;
    echo json_encode($arr);
?>;

var rowIdx = 0;
function tambahBaris(){
    var opts = '<option value="">-- Pilih Barang --</option>';
    barangList.forEach(function(b){
        opts += '<option value="'+b.kd_barang+'" data-jenis="'+b.jenis+'" data-stok="'+b.stok+'" data-harga="'+b.harga_jual+'">'+b.nama_barang+' (Stok: '+b.stok+')</option>';
    });
    var tr = '<tr id="row'+rowIdx+'">'+
        '<td><select name="kd_barang[]" onchange="pilihBarang(this,'+rowIdx+')" required>'+opts+'</select></td>'+
        '<td><input type="text" name="kode_jenis[]" id="jenis'+rowIdx+'" readonly style="background:#eee"></td>'+
        '<td><input type="text" id="stok'+rowIdx+'" readonly style="background:#eee;text-align:center"></td>'+
        '<td><input type="number" name="jumlah_barang[]" id="jml'+rowIdx+'" min="1" value="1" oninput="hitungSubtotal('+rowIdx+')" required></td>'+
        '<td><input type="number" name="harga_barang[]" id="harga'+rowIdx+'" min="0" value="0" oninput="hitungSubtotal('+rowIdx+')" required></td>'+
        '<td><input type="text" id="sub'+rowIdx+'" value="0" readonly style="background:#eee;text-align:right"></td>'+
        '<td><button type="button" onclick="hapusBaris('+rowIdx+')" class="btn-danger" style="padding:4px 10px">✕</button></td>'+
        '</tr>';
    document.getElementById('tbody-item').insertAdjacentHTML('beforeend',tr);
    rowIdx++;
}
function pilihBarang(sel, idx){
    var opt = sel.options[sel.selectedIndex];
    document.getElementById('jenis'+idx).value = opt.getAttribute('data-jenis')||'';
    document.getElementById('stok'+idx).value  = opt.getAttribute('data-stok')||0;
    document.getElementById('harga'+idx).value = opt.getAttribute('data-harga')||0;
    document.getElementById('jml'+idx).max     = opt.getAttribute('data-stok')||0;
    hitungSubtotal(idx);
}
function hitungSubtotal(idx){
    var jml   = parseInt(document.getElementById('jml'+idx).value)||0;
    var harga = parseInt(document.getElementById('harga'+idx).value)||0;
    document.getElementById('sub'+idx).value = (jml*harga).toLocaleString('id-ID');
    hitungTotal();
}
function hapusBaris(idx){
    var el = document.getElementById('row'+idx);
    if(el) el.remove();
    hitungTotal();
}
function hitungTotal(){
    var rows = document.querySelectorAll('#tbody-item tr');
    var ttlBrg=0, ttlHrg=0;
    rows.forEach(function(row){
        var idx = row.id.replace('row','');
        ttlBrg += parseInt(document.getElementById('jml'+idx).value)||0;
        ttlHrg += (parseInt(document.getElementById('jml'+idx).value)||0) * (parseInt(document.getElementById('harga'+idx).value)||0);
    });
    document.getElementById('ttl-brg').innerText = ttlBrg;
    document.getElementById('ttl-hrg').innerText = ttlHrg.toLocaleString('id-ID');
    document.getElementById('inp-ttl-brg').value = ttlBrg;
    document.getElementById('inp-ttl-hrg').value = ttlHrg;
}
tambahBaris();
</script>
</body>
</html>
