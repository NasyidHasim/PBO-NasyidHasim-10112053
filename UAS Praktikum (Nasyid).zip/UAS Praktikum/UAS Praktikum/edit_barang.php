<?php
include "koneksi.php";
$kd = mysqli_real_escape_string($koneksi, $_GET['kd']);
$q = mysqli_query($koneksi,"SELECT * FROM tb_barang WHERE kd_barang='$kd'");
$data = mysqli_fetch_array($q);
if(!$data) { header("location:data_barang.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Edit Data Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card">
        <h3> Form Edit Barang</h3>
        <a href="data_barang.php" class="tombol btn-secondary"> Kembali</a><br><br>
        <form action="update_barang.php" method="post">
            <input type="hidden" name="kd_barang_lama" value="<?= $data['kd_barang'] ?>">
            <table class="table-form">
                <tr><td>Kode Barang</td><td>:</td><td><input type="text" name="kd_barang" value="<?= $data['kd_barang'] ?>" required></td></tr>
                <tr>
                    <td>Jenis Barang</td><td>:</td>
                    <td>
                        <select name="kode_jenis" required>
                            <?php
                            $qj = mysqli_query($koneksi,"SELECT * FROM tb_jenis");
                            while($j = mysqli_fetch_array($qj)):
                            $sel = ($j['kode_jenis']==$data['kode_jenis']) ? 'selected' : '';
                            ?>
                            <option value="<?= $j['kode_jenis'] ?>" <?= $sel ?>><?= $j['jenis'] ?> (<?= $j['satuan'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </td>
                </tr>
                <tr><td>Nama Barang</td><td>:</td><td><input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>" required></td></tr>
                <tr><td>Stok</td><td>:</td><td><input type="number" name="stok" value="<?= $data['stok'] ?>" min="0" required></td></tr>
                <tr><td>Harga Beli (Rp)</td><td>:</td><td><input type="number" name="harga_beli" value="<?= $data['harga_beli'] ?>" min="0" required></td></tr>
                <tr><td>Harga Jual (Rp)</td><td>:</td><td><input type="number" name="harga_jual" value="<?= $data['harga_jual'] ?>" min="0" required></td></tr>
                <tr><td>Gambar Produk</td><td>:</td><td><input type="text" name="gambar_produk" value="<?= $data['gambar_produk'] ?>"></td></tr>
                <tr><td></td><td></td><td><input type="submit" value=" Simpan Perubahan"></td></tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>
