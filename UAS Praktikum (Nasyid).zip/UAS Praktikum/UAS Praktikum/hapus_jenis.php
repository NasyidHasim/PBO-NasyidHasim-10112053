<?php
include 'koneksi.php';
$kd = mysqli_real_escape_string($koneksi, $_GET['kd']);
mysqli_query($koneksi,"DELETE FROM tb_jenis WHERE kode_jenis='$kd'");
header("location:data_jenis.php?pesan=hapus");
exit();
?>
