<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header"><h1> Aplikasi Gudang</h1><h2>Laporan Data Barang</h2></div>
<?php include "navbar.php"; ?>
<div class="container">
    <div class="card no-print">
        <button onclick="window.print()" class="btn-info"> Cetak Laporan</button>
    </div>
    <div class="card">
        <h3> Laporan Data Barang — <?= date('d/m/Y') ?></h3>
        <table class="table">
            <tr><th>No</th><th>Kode</th><th>Nama Barang</th><th>Jenis</th><th>Satuan</th><th>Stok</th><th>Harga Beli</th><th>Harga Jual</th><th>Nilai Stok</th></tr>
            <?php
            $q = mysqli_query($koneksi,"SELECT b.*, j.jenis, j.satuan FROM tb_barang b LEFT JOIN tb_jenis j ON b.kode_jenis=j.kode_jenis ORDER BY b.kd_barang");
            $no=1; $total_nilai=0;
            while($d = mysqli_fetch_array($q)):
            $nilai = $d['stok'] * $d['harga_jual'];
            $total_nilai += $nilai;
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $d['kd_barang'] ?></td>
                <td style="text-align:left"><?= $d['nama_barang'] ?></td>
                <td><?= $d['jenis'] ?></td>
                <td><?= $d['satuan'] ?></td>
                <td style="<?= $d['stok']<=5 ? 'color:red;font-weight:bold':'' ?>"><?= $d['stok'] ?></td>
                <td>Rp <?= number_format($d['harga_beli'],0,',','.') ?></td>
                <td>Rp <?= number_format($d['harga_jual'],0,',','.') ?></td>
                <td>Rp <?= number_format($nilai,0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
            <tr style="background:#3d8b8b;color:#fff;font-weight:bold">
                <td colspan="8" style="text-align:right;padding-right:12px">TOTAL NILAI STOK</td>
                <td>Rp <?= number_format($total_nilai,0,',','.') ?></td>
            </tr>
        </table>
    </div>
</div>
</body>
</html>
