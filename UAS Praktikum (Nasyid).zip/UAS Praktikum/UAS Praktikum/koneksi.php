<?php
$host     = "localhost";
$username = "root";
$password = "";
$database = "db_inventory";

$koneksi = mysqli_connect($host, $username, $password, $database);

if (!$koneksi) {
    die("<div style='font-family:sans-serif;padding:20px;color:red;'><b>Koneksi database gagal!</b><br>" . mysqli_connect_error() . "<br><br>Pastikan:<br>1. XAMPP/MySQL sudah berjalan<br>2. Database <b>db_inventory</b> sudah diimport dari file <b>db_inventory.sql</b></div>");
}

mysqli_set_charset($koneksi, "utf8");
?>
