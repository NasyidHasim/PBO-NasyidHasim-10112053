<?php
// Redirect
header("location:data_customer.php");
exit();
?>
