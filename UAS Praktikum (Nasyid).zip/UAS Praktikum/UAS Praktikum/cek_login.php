<?php 
session_start();
include 'koneksi.php';

$username = mysqli_real_escape_string($koneksi, $_POST['username']);
$password = mysqli_real_escape_string($koneksi, $_POST['password']);

$query = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($query);

if($cek > 0){
    $data = mysqli_fetch_assoc($query);
    
    $_SESSION['username'] = $username;
    $_SESSION['tipe_user'] = $data['tipe_user'];
    $_SESSION['status'] = "login";
    
    // Jika BERHASIL, arahkan ke index.php
    header("location:index.php");
    exit();
}else{
    // Jika GAGAL, kembalikan ke login.php
    header("location:login.php?pesan=gagal");
    exit();
}
?>