-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2026 at 07:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_pembelian`
--

CREATE TABLE `detail_pembelian` (
  `no_item` int(100) NOT NULL,
  `no_pembelian` varchar(30) DEFAULT NULL,
  `kd_barang` varchar(100) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `jumlah_barang` int(30) DEFAULT NULL,
  `harga_barang` int(30) DEFAULT NULL,
  `total_harga` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_pembelian`
--

INSERT INTO `detail_pembelian` (`no_item`, `no_pembelian`, `kd_barang`, `kode_jenis`, `jumlah_barang`, `harga_barang`, `total_harga`) VALUES
(0, 'BUY - 20260617343', 'BRG03', 'ALT', 1, 32000, 32000);

-- --------------------------------------------------------

--
-- Table structure for table `detail_penjualan`
--

CREATE TABLE `detail_penjualan` (
  `no_item` int(100) NOT NULL,
  `no_penjualan` varchar(30) DEFAULT NULL,
  `kd_barang` varchar(100) DEFAULT NULL,
  `kode_jenis` varchar(30) DEFAULT NULL,
  `jumlah_barang` int(30) DEFAULT NULL,
  `harga_barang` int(30) DEFAULT NULL,
  `total_harga` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `kd_barang` varchar(100) NOT NULL,
  `kode_jenis` varchar(20) DEFAULT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `stok` int(11) DEFAULT NULL,
  `harga_beli` int(11) DEFAULT NULL,
  `harga_jual` int(11) DEFAULT NULL,
  `gambar_produk` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_barang`
--

INSERT INTO `tb_barang` (`kd_barang`, `kode_jenis`, `nama_barang`, `stok`, `harga_beli`, `harga_jual`, `gambar_produk`) VALUES
('BRG02', 'ALT', 'Pensil 2a', 60, 22000, 25000, '787-pensi-2b-faber-_16317242631.jpg'),
('BRG03', 'ALT', 'Ball Point Standard', 41, 32000, 33500, '346-0961f19e-b405-44bd-a8c0-db48123c72a4.png'),
('BRG04', 'ALT', 'Stabillo Faber Castle', 10, 65000, 68500, '312-1015915_edit.jpg'),
('BRG05', 'ALT', 'Karet Penghapus Faber Castell', 5, 15000, 18000, '129-100704547_eeaf6530-6162-4409-9dcb-e0c4d79beeb0...'),
('BRG06', 'KOM', 'Flashdisk Sandisk', 30, 320000, 335000, '562-3470099960003.jpg'),
('BRG07', 'ALT', 'Staples', 11, 32000, 33500, '251-staples-besar_1619672776.jpg'),
('BRG08', 'ALT', 'Maped Gum Stick Rubber Eraser', 35, 15000, 15500, '710-0c6f830517e7c8f272f032b161b34135.jpeg'),
('BRG09', 'ALT', 'PRONTO Clear Holder A4 10 Lembar', 24, 32000, 33000, '86-4f8eb78d1269e844215d5a23cf4434a2.jpeg'),
('BRG10', 'KOM', 'Loose Leaf', 33, 18000, 20000, '330-9db2bb1924e21211a74c9545b274788d.jpeg'),
('BRG11', 'ALT', 'Joyko Pulpen Gell', 30, 45000, 50000, '391-58c781e02009ab9a3b7f53ff34f39210.jpeg'),
('BRG12', 'ALT', 'Alat pendeteksi uang palsu Joyko', 10, 150000, 200000, '229-450c74a7-8efa-443f-b4b6-cba559cedf68.jpg'),
('BRG13', 'ALT', 'Correction Tape Joyko', 20, 12000, 13000, '518-103337120_18c97eb2-49b5-48ef-8f6e-3777d0a344d9...'),
('BRG14', 'ALT', 'Sticky Notes Joyko', 40, 5000, 6000, '929-8469ef9d4c1ea5f2a17919cf3fa95d74.jpeg'),
('BRG15', 'ALT', 'Binder Clip', 10, 35000, 40000, '255-c6ad3f97bcb6e74d1a4e9395f9f81eb36c4cbbbb_0.jpg'),
('BRG16', 'ALT', 'Cutter Joyko', 15, 3200, 4000, '863-cutter-l-500-joyko-besar-xwim_600.jpg'),
('BRG17', 'ALT', 'Dispenser Tape', 10, 8200, 10000, '139-dispenser-tape-td-103-joyko-xnno_600.png'),
('BRG18', 'ALT', 'Isi Staples', 40, 3000, 5000, '840-joyko-isi-staples-heavy-duty-no-1217s-office-s...'),
('BRG19', 'ALT', 'Gunting Joyko', 15, 12000, 15000, '49-MRT_ProdukImg_20210617163930.jpg'),
('BRG20', 'ALT', 'Pensil Warna Joyko', 20, 42000, 50000, '642-PW-joyko-2.jpg'),
('BRG21', 'ALT', 'Crayon Warna Joyko', 5, 50000, 52000, '176-WhatsApp_Image_2023-02-06_at_15_59_17.jpeg'),
('BRG22', 'ALT', 'Alat Pembolong Kertas', 30, 38000, 40000, '954-WhatsApp_Image_2023-03-27_at_08_55_40.jpeg'),
('BRG23', 'ALT', 'Pulpen Faster', 30, 32000, 33500, '739-Untitled design.jpg'),
('BRG24', 'ALT', 'Pulpen Faster', 30, 32000, 33500, '896-cambg_4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_customer`
--

CREATE TABLE `tb_customer` (
  `id_customer` varchar(100) NOT NULL,
  `nama_customer` text NOT NULL,
  `jenis_kelamin` varchar(100) DEFAULT NULL,
  `alamat_customer` text DEFAULT NULL,
  `telepon_customer` varchar(100) DEFAULT NULL,
  `email_customer` varchar(100) DEFAULT NULL,
  `pass_customer` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_customer`
--

INSERT INTO `tb_customer` (`id_customer`, `nama_customer`, `jenis_kelamin`, `alamat_customer`, `telepon_customer`, `email_customer`, `pass_customer`) VALUES
('CUS01', 'nasyid', 'Laki-laki', 'bekasi', '085717187909', 'nasyidbina@gmail.com', '$2y$10$tsAJQljqHNdubtXrVPxZZuS3NC9MnY5FQvA8MYvt1X9qJSZOVvIZC');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jenis`
--

CREATE TABLE `tb_jenis` (
  `kode_jenis` varchar(20) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `satuan` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_jenis`
--

INSERT INTO `tb_jenis` (`kode_jenis`, `jenis`, `satuan`) VALUES
('ALT', 'ALAT TULIS', 'PCS'),
('ARC', 'ARCHIVER', 'PCS'),
('CET', 'CETAKAN', 'PCS'),
('HELP', 'HELPER', 'PCS'),
('KOM', 'KOMPUTER', 'PCS');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembelian`
--

CREATE TABLE `tb_pembelian` (
  `no_pembelian` varchar(100) NOT NULL,
  `tanggal_pembelian` varchar(30) DEFAULT NULL,
  `id_supplier` varchar(100) DEFAULT NULL,
  `total_barangall` int(30) DEFAULT NULL,
  `total_hargaall` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_pembelian`
--

INSERT INTO `tb_pembelian` (`no_pembelian`, `tanggal_pembelian`, `id_supplier`, `total_barangall`, `total_hargaall`) VALUES
('BUY - 20260617281', '2026-06-17', 'SUP01', 0, 0),
('BUY - 20260617340', '2026-06-17', 'SUP01', 0, 0),
('BUY - 20260617343', '2026-06-17', 'SUP01', 1, 32000),
('BUY - 20260617748', '2026-06-17', 'SUP01', 0, 0),
('BUY - 20260617892', '2026-06-17', 'SUP01', 0, 0),
('PB0001', '2026-06-17', 'SUP01', 1, 18000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_penjualan`
--

CREATE TABLE `tb_penjualan` (
  `no_penjualan` varchar(100) NOT NULL,
  `tanggal_penjualan` varchar(30) DEFAULT NULL,
  `id_customer` varchar(100) DEFAULT NULL,
  `total_barangall` int(30) DEFAULT NULL,
  `total_hargaall` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_penjualan`
--

INSERT INTO `tb_penjualan` (`no_penjualan`, `tanggal_penjualan`, `id_customer`, `total_barangall`, `total_hargaall`) VALUES
('JUL0001', '2026-06-17', 'CUS01', 0, 0),
('PJ0001', '2026-06-17', 'CUS01', 1, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_supplier`
--

CREATE TABLE `tb_supplier` (
  `id_supplier` varchar(100) NOT NULL,
  `nama_supplier` text NOT NULL,
  `alamat_supplier` text DEFAULT NULL,
  `telepon_supplier` varchar(100) DEFAULT NULL,
  `email_supplier` varchar(100) DEFAULT NULL,
  `pass_supplier` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_supplier`
--

INSERT INTO `tb_supplier` (`id_supplier`, `nama_supplier`, `alamat_supplier`, `telepon_supplier`, `email_supplier`, `pass_supplier`) VALUES
('SUP01', 'Nasyid', 'bekasi', '085717187909', 'nasyidbina@gmail.com', '$2y$10$MiORzIdAn4VS94DzIIc4geoc5C1XLrzl6JBYN4h3VqXRI0G7tbUsm');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tipe_user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `tipe_user`) VALUES
(1, 'Nasyid', '123', 'Administrator'),
(3, 'uwow', '12', 'Customer'),
(4, '', '123', 'Staff'),
(6, 'fulan', '123', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD PRIMARY KEY (`no_item`),
  ADD KEY `no_pembelian` (`no_pembelian`),
  ADD KEY `kd_barang` (`kd_barang`),
  ADD KEY `kode_jenis` (`kode_jenis`);

--
-- Indexes for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD PRIMARY KEY (`no_item`),
  ADD KEY `no_penjualan` (`no_penjualan`),
  ADD KEY `kd_barang` (`kd_barang`),
  ADD KEY `kode_jenis` (`kode_jenis`);

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`kd_barang`),
  ADD KEY `kode_jenis` (`kode_jenis`);

--
-- Indexes for table `tb_customer`
--
ALTER TABLE `tb_customer`
  ADD PRIMARY KEY (`id_customer`);

--
-- Indexes for table `tb_jenis`
--
ALTER TABLE `tb_jenis`
  ADD PRIMARY KEY (`kode_jenis`);

--
-- Indexes for table `tb_pembelian`
--
ALTER TABLE `tb_pembelian`
  ADD PRIMARY KEY (`no_pembelian`),
  ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  ADD PRIMARY KEY (`no_penjualan`),
  ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `tb_supplier`
--
ALTER TABLE `tb_supplier`
  ADD PRIMARY KEY (`id_supplier`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD CONSTRAINT `detail_pembelian_ibfk_1` FOREIGN KEY (`no_pembelian`) REFERENCES `tb_pembelian` (`no_pembelian`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_pembelian_ibfk_2` FOREIGN KEY (`kd_barang`) REFERENCES `tb_barang` (`kd_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_pembelian_ibfk_3` FOREIGN KEY (`kode_jenis`) REFERENCES `tb_jenis` (`kode_jenis`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD CONSTRAINT `detail_penjualan_ibfk_1` FOREIGN KEY (`no_penjualan`) REFERENCES `tb_penjualan` (`no_penjualan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_penjualan_ibfk_2` FOREIGN KEY (`kd_barang`) REFERENCES `tb_barang` (`kd_barang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_penjualan_ibfk_3` FOREIGN KEY (`kode_jenis`) REFERENCES `tb_jenis` (`kode_jenis`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD CONSTRAINT `tb_barang_ibfk_1` FOREIGN KEY (`kode_jenis`) REFERENCES `tb_jenis` (`kode_jenis`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tb_pembelian`
--
ALTER TABLE `tb_pembelian`
  ADD CONSTRAINT `tb_pembelian_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `tb_supplier` (`id_supplier`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  ADD CONSTRAINT `tb_penjualan_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `tb_customer` (`id_customer`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
